# AWS Labs 

These labs are part of our EC2 Course on Udemy. [Click here](https://www.udemy.com/ec2with10labs/?couponCode=GITPPON) to buy the full course for $9.99

If you have any questions please ask them [here](https://github.com/Cloud-Yeti/aws-ec2-course/issues/new) by opening an issue. 
